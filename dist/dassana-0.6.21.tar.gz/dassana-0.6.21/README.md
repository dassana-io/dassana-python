# dassana-python
A python module for building Dassana data ingestions

https://pypi.org/project/dassana/
